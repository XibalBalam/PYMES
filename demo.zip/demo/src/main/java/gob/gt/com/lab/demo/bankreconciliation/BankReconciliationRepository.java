package gob.gt.com.lab.demo.bankreconciliation;

import org.springframework.data.jpa.repository.JpaRepository;

public interface BankReconciliationRepository extends JpaRepository<BankReconciliation, Long> {
}
